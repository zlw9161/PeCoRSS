"""Classes to load datasets"""
import os
import numpy as np
import torch
from skimage import transform
from pathlib import Path
from torch.utils.data import Dataset
from torch.utils.data import DataLoader

from svrss.loaders.dataset import CWRdata, XPDdata, RDSyn, NuaaSim
from svrss.utils.paths import Paths


class SequenceDataset(Dataset):
    """DataLoader class for dataset sequences"""

    def __init__(self, dataset):
        self.dataset = dataset
        self.seq_names = list(self.dataset.keys())

    def __len__(self):
        return len(self.seq_names)

    def __getitem__(self, idx):
        seq_name = self.seq_names[idx]
        return seq_name, self.dataset[seq_name]


class PeCoRSVDataset(Dataset):
    """DataLoader class for Radar sequences from different sources
    Load frames, only for semantic segmentation
    Specific to load several frames at the same time (sub sequences)
    Aggregated Tensor Input + Multiple Output

    PARAMETERS
    ----------
    dataset: SequenceCarradaDataset object
    annotation_type: str
        Supported annotations are 'sparse', 'dense'
    path_to_frames: str
        Path to the frames of a given sequence (folder of the sequence)
    process_signal: boolean
        Load signal w/ or w/o processing (power, log transform)
    n_frame: int
        Number of frames used for each sample
    transformations: list of functions
        Preprocessing or data augmentation functions
        Default: None
    add_temp: boolean
        Formating the input tensors as sequences
        Default: False
    """

    def __init__(self, dataset, dataset_type, annotation_type, signal_type, path_to_frames, process_signal,
                 n_frames, cmplx_flag=False, transformations=None, add_temp=False):
        self.dataset = dataset
        self.dataset_type = dataset_type
        self.annotation_type = annotation_type
        self.signal_type = signal_type
        self.path_to_frames = Path(path_to_frames)
        self.process_signal = process_signal
        self.n_frames = n_frames
        self.cmplx_flag = cmplx_flag
        self.transformations = transformations
        self.add_temp = add_temp
        # self.dataset = self.dataset[self.n_frames-1:]  # remove n first frames
        if self.dataset_type in ['CarradaRAC_RD', 'CarradaRAC_RA']:
            self.path_to_annots = self.path_to_frames / 'new_annotations' / self.annotation_type
        else:
            self.path_to_annots = self.path_to_frames / 'annotations' / self.annotation_type

    def transform(self, frame, is_vflip=False, is_hflip=False):
        """
        Method to apply preprocessing / data augmentation functions

        PARAMETERS
        ----------
        frame: dict
            Contains the matrices and the masks on which we want to apply the transformations
        is_vfilp: boolean
            If you want to apply a vertical flip
            Default: False
        is_hfilp: boolean
            If you want to apply a horizontal flip
            Default: False

        RETURNS
        -------
        frame: dict
        """
        if self.transformations is not None:
            for function in self.transformations:
                if isinstance(function, VFlip):
                    if is_vflip:
                        frame = function(frame)
                    else:
                        continue
                if isinstance(function, HFlip):
                    if is_hflip:
                        frame = function(frame)
                    else:
                        continue
                if not isinstance(function, VFlip) and not isinstance(function, HFlip):
                    frame = function(frame)
        return frame

    def __len__(self):
        """Number of frames per sequence"""
        return len(self.dataset[self.n_frames-1:])

    def __getitem__(self, idx):
        init_frame_name = self.dataset[idx+self.n_frames-1][0]
        if self.dataset_type in ['Carrada_RD', 'Carrada_RA', 'CarradaRAC_RD', 'CarradaRAC_RA']:
            frame_id = int(init_frame_name)
            frame_names = [str(f_id).zfill(6) for f_id in range(frame_id-self.n_frames+1, frame_id+1)]
        else:
            frame_names = [self.dataset[f_id][0] for f_id in range(idx, idx+self.n_frames)]
        rd_matrices = list()
        # ra_matrices = list()
        # ad_matrices = list()
        # rd_mask = np.load(os.path.join(self.path_to_annots, init_frame_name,
        #                                self.signal_type + '.npy')).astype(np.float32)
        rd_mask = np.load(os.path.join(self.path_to_annots, init_frame_name,
                                       self.signal_type + '.npy'))
        if self.dataset_type == "LSFJamming":
            import torch.nn.functional as F
            rd_mask = F.one_hot(torch.from_numpy(rd_mask).long(), num_classes=9).permute(2, 0, 1).float().numpy()
        
        # ra_mask = np.load(os.path.join(self.path_to_annots, init_frame_name,
        #                                'range_angle.npy'))

        for frame_name in frame_names:
            if self.dataset_type in ['Carrada_RD', 'Carrada_RA', 'CarradaRAC_RD', 'CarradaRAC_RA']:
                if self.process_signal:
                    rd_matrix = np.load(os.path.join(self.path_to_frames,
                                                    self.signal_type + '_processed',
                                                    frame_name + '.npy'))
                else:
                    rd_matrix = np.load(os.path.join(self.path_to_frames,
                                                    self.signal_type + '_raw',
                                                    frame_name + '.npy'))
            elif self.dataset_type == 'XPDdata':
                rd_matrix = np.load(os.path.join(self.path_to_frames,
                                                 self.signal_type + '_mtdData_amp',
                                                 frame_name + '.npy'))
            elif self.dataset_type == 'NuaaSim':
                if self.cmplx_flag:
                    rd_matrix = np.load(os.path.join(self.path_to_frames,
                                                    self.signal_type + '_echo',
                                                    frame_name + '.npy'))
                    # if len(rd_matrix.size) == 4:
                    #     rd_matrix = rd_matrix[0,...]
                else:
                    rd_matrix = np.load(os.path.join(self.path_to_frames,
                                                    self.signal_type + '_mtdData_amp',
                                                    frame_name + '.npy'))
            elif self.dataset_type == 'LSFJamming':
                if self.cmplx_flag:
                    rd_matrix_temp = np.load(os.path.join(self.path_to_frames,
                                                    self.signal_type + '_echo',
                                                    frame_name + '.npy'))
                    real_part = rd_matrix_temp[0, ...]
                    imag_part = rd_matrix_temp[1, ...]
                    rd_matrix = real_part + 1j * imag_part
                    # rd_matrix = np.load(os.path.join(self.path_to_frames,
                    #                                 self.signal_type + '_echo',
                    #                                 frame_name + '.npy'))
                else:
                    rd_matrix_temp = np.load(os.path.join(self.path_to_frames,
                                                    self.signal_type + '_MTD',
                                                    frame_name + '.npy'))
                    rd_matrix = np.abs(rd_matrix_temp[0,:,:] + 1j*rd_matrix_temp[1,:,:])
            else:
                rd_matrix = np.load(os.path.join(self.path_to_frames,
                                                 self.signal_type + '_numpy',
                                                 frame_name + '.npy'))

            rd_matrices.append(rd_matrix)
            # ra_matrices.append(ra_matrix)
            # ad_matrices.append(ad_matrix)

        # Apply the same transfo to all representations
        if np.random.uniform(0, 1) > 0.5:
            is_vflip = True
        else:
            is_vflip = False
        if np.random.uniform(0, 1) > 0.5:
            is_hflip = True
        else:
            is_hflip = False

        # rd_matrix = np.dstack(rd_matrices)
        # rd_matrix = np.rollaxis(rd_matrix, axis=-1)
        #ycc
        rd_matrix = np.array([np.array(sub_list) for sub_list in rd_matrices])
        # if self.cmplx_flag:
        #     rd_matrix = rd_matrix.transpose((1,0,2,3))

        rd_frame = {'matrix': rd_matrix, 'mask': rd_mask}
        rd_frame = self.transform(rd_frame, is_vflip=is_vflip, is_hflip=is_hflip)
        if self.add_temp:
            if isinstance(self.add_temp, bool):
                rd_frame['matrix'] = np.expand_dims(rd_frame['matrix'], axis=0)
            else:
                assert isinstance(self.add_temp, int)
                rd_frame['matrix'] = np.expand_dims(rd_frame['matrix'],
                                                    axis=self.add_temp)

        frame = {'rd_matrix': rd_frame['matrix'], 'rd_mask': rd_frame['mask']}

        return frame


class Rescale:
    """Rescale the image in a sample to a given size.

    PARAMETERS
    ----------
    output_size: tuple or int
        Desired output size. If tuple, output is
        matched to output_size. If int, smaller of image edges is matched
        to output_size keeping aspect ratio the same.
    """

    def __init__(self, output_size):
        assert isinstance(output_size, (int, tuple))
        self.output_size = output_size

    def __call__(self, frame):
        matrix, rd_mask, ra_mask = frame['matrix'], frame['rd_mask'], frame['ra_mask']
        h, w = matrix.shape[1:]
        if isinstance(self.output_size, int):
            if h > w:
                new_h, new_w = self.output_size * h / w, self.output_size
            else:
                new_h, new_w = self.output_size, self.output_size * w / h
        else:
            new_h, new_w = self.output_size
        new_h, new_w = int(new_h), int(new_w)
        # transform.resize induce a smoothing effect on the values
        # transform only the input data
        matrix = transform.resize(matrix, (matrix.shape[0], new_h, new_w))
        return {'matrix': matrix, 'rd_mask': rd_mask, 'ra_mask': ra_mask}


class Flip:
    """
    Randomly flip the matrix with a proba p
    """

    def __init__(self, proba):
        assert proba <= 1.
        self.proba = proba

    def __call__(self, frame):
        matrix, mask = frame['matrix'], frame['mask']
        h_flip_proba = np.random.uniform(0, 1)
        if h_flip_proba < self.proba:
            matrix = np.flip(matrix, axis=1).copy()
            mask = np.flip(mask, axis=1).copy()
        v_flip_proba = np.random.uniform(0, 1)
        if v_flip_proba < self.proba:
            matrix = np.flip(matrix, axis=2).copy()
            mask = np.flip(mask, axis=2).copy()
        return {'matrix': matrix, 'mask': mask}


class HFlip:
    """
    Randomly horizontal flip the matrix with a proba p
    """

    def __init__(self):
        pass

    def __call__(self, frame):
        matrix, mask = frame['matrix'], frame['mask']
        matrix = np.flip(matrix, axis=1).copy()
        mask = np.flip(mask, axis=1).copy()
        return {'matrix': matrix, 'mask': mask}


class VFlip:
    """
    Randomly vertical flip the matrix with a proba p
    """

    def __init__(self):
        pass

    def __call__(self, frame):
        matrix, mask = frame['matrix'], frame['mask']
        matrix = np.flip(matrix, axis=2).copy()
        mask = np.flip(mask, axis=2).copy()
        return {'matrix': matrix, 'mask': mask}


def test_sequence():
    dataset = CWRdata().get('Train')
    dataloader = DataLoader(SequenceDataset(dataset), batch_size=1,
                            shuffle=False, num_workers=0)
    for i, data in enumerate(dataloader):
        seq_name, seq = data
        if i == 0:
            seq = [subseq[0] for subseq in seq]
            assert seq_name[0] == '2020年11月11日15时50分44秒_mtd_mid'
            assert 'MTD_Scan_1_27' in seq
        else:
            break


def test_XPDdata():
    paths = Paths().get()
    n_frames = 3
    dataset = XPDdata().get('Train')
    seq_dataloader = DataLoader(SequenceDataset(dataset), batch_size=1,
                                shuffle=True, num_workers=0)
    for _, data in enumerate(seq_dataloader):
        seq_name, seq = data
        path_to_frames = paths['XPDdata'] / seq_name[0]
        frame_dataloader = DataLoader(PeCoRSVDataset(seq,
                                                     'XPDdata',
                                                     'dense',
                                                     'range_doppler',
                                                     path_to_frames,
                                                     process_signal=True,
                                                     n_frames=n_frames),
                                      shuffle=False,
                                      batch_size=1,
                                      num_workers=0)
        for _, frame in enumerate(frame_dataloader):
            assert list(frame['rd_matrix'].shape[2:]) == [64, 148]
            print(frame['rd_matrix'].shape)
            # assert list(frame['ra_matrix'].shape[2:]) == [256, 256]
            # assert list(frame['ad_matrix'].shape[2:]) == [256, 64]
            assert frame['rd_matrix'].shape[1] == n_frames
            assert list(frame['rd_mask'].shape[2:]) == [64, 148]
            print(frame['rd_mask'].shape)
            # assert list(frame['ra_mask'].shape[2:]) == [256, 256]
        break


def test_Nuaa():
    paths = Paths().get()
    n_frames = 3
    dataset = NuaaSim().get('Train')
    seq_dataloader = DataLoader(SequenceDataset(dataset), batch_size=1,
                                shuffle=True, num_workers=0)
    for _, data in enumerate(seq_dataloader):
        seq_name, seq = data
        path_to_frames = paths['NuaaSim'] / seq_name[0]
        frame_dataloader = DataLoader(PeCoRSVDataset(seq,
                                                     'NuaaSim',
                                                     'dense',
                                                     'range_doppler',
                                                     path_to_frames,
                                                     process_signal=True,
                                                     n_frames=n_frames,
                                                     cmplx_flag=False),
                                      shuffle=False,
                                      batch_size=1,
                                      num_workers=0)
        for _, frame in enumerate(frame_dataloader):
            assert list(frame['rd_matrix'].shape[2:]) == [128, 1024]
            print(frame['rd_matrix'].shape)
            # assert list(frame['ra_matrix'].shape[2:]) == [256, 256]
            # assert list(frame['ad_matrix'].shape[2:]) == [256, 64]
            assert frame['rd_matrix'].shape[1] == n_frames
            assert list(frame['rd_mask'].shape[2:]) == [128, 1024]
            print(frame['rd_mask'].shape)
            # assert list(frame['ra_mask'].shape[2:]) == [256, 256]
        break


def test_subflip():
    paths = Paths().get()
    n_frames = 3
    dataset = CWRdata().get('Train')
    seq_dataloader = DataLoader(SequenceDataset(dataset), batch_size=1,
                                shuffle=True, num_workers=0)
    for _, data in enumerate(seq_dataloader):
        seq_name, seq = data
        path_to_frames = paths['CWRdata'] / seq_name[0]
        frame_dataloader = DataLoader(PeCoRSVDataset(seq,
                                                     'dense',
                                                     path_to_frames,
                                                     process_signal=True,
                                                     n_frames=n_frames),
                                      shuffle=False,
                                      batch_size=1,
                                      num_workers=0)
        for _, frame in enumerate(frame_dataloader):
            rd_matrix = frame['rd_matrix'][0].cpu().detach().numpy()
            rd_mask = frame['rd_mask'][0].cpu().detach().numpy()
            rd_frame_test = {'matrix': rd_matrix,
                             'mask': rd_mask}
            rd_frame_vflip = VFlip()(rd_frame_test)
            rd_matrix_vflip = rd_frame_vflip['matrix']
            rd_frame_hflip = HFlip()(rd_frame_test)
            rd_matrix_hflip = rd_frame_hflip['matrix']
            assert rd_matrix[0][0][0] == rd_matrix_vflip[0][0][-1]
            assert rd_matrix[0][0][-1] == rd_matrix_vflip[0][0][0]
            assert rd_matrix[0][0][0] == rd_matrix_hflip[0][-1][0]
            assert rd_matrix[0][-1][0] == rd_matrix_hflip[0][0][0]
        break


def test_snr_eval():
    paths = Paths().get()
    n_frames = 1
    dataset = NuaaSim().get('Train')
    seq_dataloader = DataLoader(SequenceDataset(dataset), batch_size=1,
                                shuffle=True, num_workers=0)
    for _, data in enumerate(seq_dataloader):
        seq_name, seq = data

        path_to_frames = paths['NuaaSim'] / seq_name[0]
        frame_dataloader = DataLoader(PeCoRSVDataset(seq,
                                                     'NuaaSim',
                                                     'dense',
                                                     'range_doppler',
                                                     path_to_frames,
                                                     process_signal=True,
                                                     n_frames=n_frames,
                                                     cmplx_flag=False),
                                      shuffle=False,
                                      batch_size=1,
                                      num_workers=0)
        for _, frame in enumerate(frame_dataloader):
            data = frame['rd_matrix']
            mask = torch.argmax(frame['rd_mask'],dim=1)
            signal_power = ((data*mask)**2).sum()/mask.sum()
            noise_power = ((data*(1-mask))**2).sum()/(1-mask).sum()
            SNR = 10*np.log10(signal_power/noise_power)
            print(SNR)




    
if __name__ == '__main__':
    #test_sequence()
    # test_Nuaa()
    #test_subflip()
    test_snr_eval()
